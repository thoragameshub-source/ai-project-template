# 🧩 Prompts de planejamento — nível 🟢 SIMPLES

> Gerado para o nível do projeto: só aparecem os arquivos que existem no seu SOURCE. Troque os `[[campos]]` pelos seus dados.
> O startup já pré-preencheu o que você respondeu; comece pelo **P0** para ver o que falta.

## Prompts de controle

| Momento | Prompt direto |
|---|---|
| **P0 — Abrir sessão de planejamento** | Leia MODO.md e AGENTS.md. Confirme em uma linha o modo e o nível. Liste os arquivos do SOURCE que ainda têm placeholders <...> e as pendências de ARTEFATO/_logs/pendencias-startup.md. Não edite nada até eu indicar o arquivo. |
| **PC — Checar consistência** | Modo PLANEJAMENTO. Leia todo o SOURCE e escreva em ARTEFATO/_rascunhos/relatorio-consistencia.md: contradições entre arquivos, lacunas, termos fora do glossário e números duplicados. Não edite o SOURCE. |
| **PG — Gate de congelamento** | Aplique o checklist de congelamento de MODO.md (núcleo preenchido e módulos não usados apagados) e responda se o SOURCE está pronto para EXECUÇÃO, listando pendências. Não altere o MODO.md. |
| **PE — Abrir sessão de execução** | Leia MODO.md e AGENTS.md. Confirme que o modo é EXECUCAO. Não edite nada em SOURCE. Se encontrar erro ou lacuna, crie uma proposta em ARTEFATO/_propostas-source/. Tarefa: [[tarefa]]. |
| **PV — Voltar ao planejamento** | (Primeiro eu mudo MODO.md para PLANEJAMENTO.) Modo PLANEJAMENTO retomado. Motivo: [[motivo]]. Edite apenas [[arquivo(s)]] com base em [[propostas aceitas / decisão]] e registre no changelog-source. |

## Planejamento do nível

### 🟢 Prompt único do nível SIMPLES
Use este prompt primeiro; a tabela por arquivo serve para refinar um arquivo específico.

> Modo PLANEJAMENTO, nível SIMPLES. O startup já pré-preencheu parte do SOURCE. Complete somente estes arquivos do SOURCE: contexto-master.md, 00-produto/visao-e-escopo.md, 02-tecnico/stack.md, 03-agentes/guardrails.md, 03-agentes/skills/revisar-entrega.md, 04-qualidade/definicao-de-pronto.md. Dados: objetivo em 3 linhas [[objetivo]]; quem usa [[usuário]]; dentro e fora do escopo [[escopo]]; stack e versões [[stack]]; ações proibidas e que exigem aprovação [[guardrails]]; critérios de pronto [[pronto]]. Siga o template de cada arquivo, não invente (use 'a confirmar'), mantenha o contexto-master em até 40 linhas, atualize ARTEFATO/_logs/pendencias-startup.md e registre tudo em ARTEFATO/_logs/changelog-source.md.

## Prompts por arquivo

| # | Arquivo | Informações cruciais a fornecer | Prompt direto (copie e preencha os [[campos]]) |
|---|---|---|---|
| 1 | `SOURCE/contexto-master.md` | nome do projeto; objetivo em 3-5 linhas; perfis de usuário e o que fazem com o resultado; 3 a 7 regras inegociáveis; módulos mantidos | Modo PLANEJAMENTO: edite SOURCE/contexto-master.md. Dados: [[nome do projeto]]; [[objetivo em 3-5 linhas]]; [[perfis de usuário e o que fazem com o resultado]]; [[3 a 7 regras inegociáveis]]; [[módulos mantidos]]. Preencha todas as seções, monte o mapa 'leia quando' só com arquivos que existem e mantenha até 2 páginas. Reexecute ao final do planejamento para atualizar o mapa. Siga o template do arquivo, troque os exemplos pelos meus dados, não invente (use 'a confirmar') e registre no ARTEFATO/_logs/changelog-source.md. |
| 2 | `SOURCE/00-produto/visao-e-escopo.md` | problema; objetivo mensurável; resultado esperado; itens dentro do escopo; itens fora do escopo; premissas e restrições; métricas (hoje e meta) | Modo PLANEJAMENTO: edite SOURCE/00-produto/visao-e-escopo.md. Dados: [[problema]]; [[objetivo mensurável]]; [[resultado esperado]]; [[itens dentro do escopo]]; [[itens fora do escopo]]; [[premissas e restrições]]; [[métricas (hoje e meta)]]. Escreva de forma objetiva; o 'fora do escopo' deve ser explícito. Siga o template do arquivo, troque os exemplos pelos meus dados, não invente (use 'a confirmar') e registre no ARTEFATO/_logs/changelog-source.md. |
| 3 | `SOURCE/02-tecnico/stack.md` | linguagem e versão; framework; banco/armazenamento; modelo de IA a usar; bibliotecas permitidas e proibidas; nomes (sem valores) das variáveis de ambiente | Modo PLANEJAMENTO: edite SOURCE/02-tecnico/stack.md. Dados: [[linguagem e versão]]; [[framework]]; [[banco/armazenamento]]; [[modelo de IA a usar]]; [[bibliotecas permitidas e proibidas]]; [[nomes (sem valores) das variáveis de ambiente]]. Justifique cada escolha em uma linha. Siga o template do arquivo, troque os exemplos pelos meus dados, não invente (use 'a confirmar') e registre no ARTEFATO/_logs/changelog-source.md. |
| 4 | `SOURCE/03-agentes/guardrails.md` | ações proibidas; ações que exigem aprovação e quem aprova; ações livres; dados sensíveis e como tratá-los | Modo PLANEJAMENTO: edite SOURCE/03-agentes/guardrails.md. Dados: [[ações proibidas]]; [[ações que exigem aprovação e quem aprova]]; [[ações livres]]; [[dados sensíveis e como tratá-los]]. Mantenha a regra de modos: SOURCE só é editável em PLANEJAMENTO. Siga o template do arquivo, troque os exemplos pelos meus dados, não invente (use 'a confirmar') e registre no ARTEFATO/_logs/changelog-source.md. |
| 5 | `SOURCE/03-agentes/skills/revisar-entrega.md` | o que será auditado; fontes de verdade a conferir; formato do parecer | Modo PLANEJAMENTO: edite SOURCE/03-agentes/skills/revisar-entrega.md. Dados: [[o que será auditado]]; [[fontes de verdade a conferir]]; [[formato do parecer]]. Mantenha a regra: quem revisa não é quem produziu e nunca marca 'aprovado'. Siga o template do arquivo, troque os exemplos pelos meus dados, não invente (use 'a confirmar') e registre no ARTEFATO/_logs/changelog-source.md. |
| 6 | `SOURCE/04-qualidade/definicao-de-pronto.md` | critérios obrigatórios de entrega; critérios específicos do projeto; quem aprova cada tipo de entrega | Modo PLANEJAMENTO: edite SOURCE/04-qualidade/definicao-de-pronto.md. Dados: [[critérios obrigatórios de entrega]]; [[critérios específicos do projeto]]; [[quem aprova cada tipo de entrega]]. Liste como checklist e mantenha a tabela de status. Siga o template do arquivo, troque os exemplos pelos meus dados, não invente (use 'a confirmar') e registre no ARTEFATO/_logs/changelog-source.md. |

**Como usar bem**
1. Um arquivo (ou uma pasta, no MÉDIO) por vez; revise antes de seguir.
2. Dado que falta vira `a confirmar` e entra em `ARTEFATO/_logs/pendencias-startup.md`.
3. Ao final, reexecute o prompt do `contexto-master.md` para atualizar o mapa.
