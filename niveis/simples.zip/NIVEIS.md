# 🎚️ Níveis de complexidade — `ai-project-template`

> Objetivo: **agilidade e economia de tokens**. Quanto menos arquivos a IA lê e mantém, menos contexto gasto e menos retrabalho. Cada projeto usa **o menor nível que o protege de erros**. O nível é definido no **Startup building** (veja a seção 4).

## 1. Os três níveis

| | 🟢 SIMPLES | 🟡 MÉDIO | 🔴 COMPLEXO |
|---|---|---|---|
| **Exemplos** | Automação pontual (robô de relatório), script, landing page, documento | Agente com integrações, MVP de SaaS, automação entre sistemas, app de uma área | SaaS com clientes pagantes, vários agentes, integrações críticas, múltiplos times |
| **Arquivos obrigatórios no SOURCE** | 6 | 13 | 15 (+ módulos opcionais) |
| **Congelamento do SOURCE** | opcional | por tag | gate completo (PC + PG), revisão humana |
| **Prompts de planejamento** | 1 prompt único | 1 por pasta | 1 por arquivo |
| **Limite do `contexto-master.md`** | 40 linhas | 80 linhas | 120 linhas |

> As permissões do `MODO.md` valem **nos três níveis**: em EXECUÇÃO a IA nunca edita o SOURCE.

## 2. Pontuação (5 perguntas)

Cada resposta vale 0, 1 ou 2 pontos.

| # | Pergunta | 0 ponto | 1 ponto | 2 pontos |
|---|---|---|---|---|
| 1 | **Tamanho e prazo** | Entrega em até 1 semana, 1 pessoa | 2 a 8 semanas, 2 a 3 pessoas | Mais de 2 meses ou mais de 3 pessoas |
| 2 | **Integrações externas (APIs, ERPs, bancos, pagamentos)** | 0 a 1, de baixo risco | 2 a 4 | 5 ou mais, ou qualquer integração crítica (pagamento, fiscal) |
| 3 | **Agentes e automações encadeadas** | 1 agente ou 1 fluxo simples | 2 a 3 etapas ou agentes | 4 ou mais, ou agentes autônomos em produção |
| 4 | **Dados e impacto** | Nenhum dado sensível, uso interno | Dados internos da empresa ou de clientes sem impacto financeiro | Dados pessoais (LGPD), financeiros ou usuários pagantes |
| 5 | **Aprovação e equipe** | 1 pessoa aprova | 2 a 3 pessoas | Times ou papéis separados (produto, técnico, jurídico) |

| Pontos | Nível |
|---|---|
| 0 a 3 | 🟢 SIMPLES |
| 4 a 7 | 🟡 MÉDIO |
| 8 a 10 | 🔴 COMPLEXO |

**Ajustes obrigatórios**

- Pergunta 2 com resposta **2**: no mínimo **MEDIO** (integração crítica (pagamento, fiscal)).
- Pergunta 4 com resposta **2**: no mínimo **MEDIO** (dados pessoais, financeiros ou usuários pagantes).
- Três ou mais respostas **2**: **COMPLEXO**.
- Na dúvida entre dois níveis, fique no **menor** e promova depois (é barato; o inverso gera retrabalho).

## 3. Arquivos por nível

✅ obrigatório · ➖ opcional (vem no pacote; mantenha só se usar) · — não existe neste nível

| Arquivo | 🟢 Simples | 🟡 Médio | 🔴 Complexo |
|---|:-:|:-:|:-:|
| `00-produto/requisitos.md` | — | ✅ | ✅ |
| `00-produto/visao-e-escopo.md` | ✅ | ✅ | ✅ |
| `01-dominio/fontes-de-verdade.md` | — | — | ✅ |
| `01-dominio/glossario.md` | — | ✅ | ✅ |
| `01-dominio/regras-de-negocio.md` | — | ✅ | ✅ |
| `02-tecnico/arquitetura.md` | — | ✅ | ✅ |
| `02-tecnico/convencoes.md` | — | ✅ | ✅ |
| `02-tecnico/stack.md` | ✅ | ✅ | ✅ |
| `03-agentes/guardrails.md` | ✅ | ✅ | ✅ |
| `03-agentes/papeis-e-fluxo.md` | — | — | ➖ |
| `03-agentes/skills/escrever-codigo.md` | — | ➖ | ➖ |
| `03-agentes/skills/escrever-documento.md` | — | ➖ | ➖ |
| `03-agentes/skills/revisar-entrega.md` | ✅ | ✅ | ✅ |
| `04-qualidade/checklist-revisao.md` | — | ✅ | ✅ |
| `04-qualidade/definicao-de-pronto.md` | ✅ | ✅ | ✅ |
| `05-referencias/exemplos-de-saida/exemplo-documento.md` | — | — | ➖ |
| `05-referencias/schemas/exemplo-payload.md` | — | — | ➖ |
| `05-referencias/templates/template-documento.md` | — | — | ✅ |
| `05-referencias/templates/template-prompt.md` | — | — | ➖ |
| `06-decisoes/ADR-000-modelo.md` | — | ✅ | ✅ |
| `06-decisoes/ADR-001-exemplo.md` | — | — | ➖ |
| `contexto-master.md` | ✅ | ✅ | ✅ |

> Fonte: `niveis.json` (gerado pela factory). Não edite à mão.

## 4. Como o nível é definido

**Automático (recomendado): Startup building.** O template nasce em `modo: STARTUP`. Ao abrir o projeto e digitar `/startup` (Claude Code) ou "startup" (Cowork/outros agentes), o agente faz até 2 rodadas de perguntas, calcula a pontuação com `tools/startup.py pontuar`, mostra o **diagnóstico** para você aprovar, cria a estrutura do nível a partir de `niveis/<nivel>.zip`, pré-preenche o SOURCE, renomeia a pasta e entra em **PLANEJAMENTO**.

**Manual:** baixe `niveis/<nivel>.zip` do repositório do template, descompacte numa pasta com o nome do projeto (`NOMENCLATURA.md`) e preencha `projeto:` no `MODO.md`.

## 5. Prompts por nível
Os prompts do seu nível estão em `PROMPTS-PLANEJAMENTO.md` (gerado só com os arquivos que você tem).

## 6. Promoção de nível

**Quando promover**

- Surgiu uma integração crítica (pagamento, fiscal) ou dados pessoais de clientes
- Mais de um agente ou automação encadeada passou a rodar em produção
- Mais de 2 pessoas passaram a aprovar entregas
- O mesmo erro de contexto se repete (a IA 'esquece' regras): falta um arquivo do próximo nível

**Como promover** (humano roda; baixe `niveis/complexo.zip` do template):
```
python tools/nivel.py promover --nivel MEDIO --origem complexo.zip
python tools/nivel.py promover --nivel MEDIO --origem complexo.zip --aplicar
```
1. O comando copia os arquivos que faltam e atualiza o `nivel:` do `MODO.md`.
2. Volte `modo:` para `PLANEJAMENTO` (registre o motivo no `MODO.md`).
3. Gere só os arquivos novos com os prompts do novo nível e atualize o mapa do `contexto-master.md`.
4. Rode `verificar`, congele de novo e incremente a versão do SOURCE.

## 7. Regras de economia de tokens

1. **Contexto-master curto**: respeite o limite do nível; detalhe vai nos outros arquivos.
2. **Mapa "leia quando..."**: a IA lê só o que a tarefa pede.
3. **Um arquivo por vez** em PLANEJAMENTO (no MÉDIO, uma pasta por vez).
4. **Sem duplicação**: um fato mora em um arquivo; os outros apontam para ele.
5. **Sem arquivo vazio**: módulo opcional que você não usa deve ser apagado, junto com a linha dele no mapa do `contexto-master.md`.
6. **Exemplos reais curtos** valem mais que instruções longas.
7. **Não reexplique o projeto na conversa**: melhore o SOURCE em PLANEJAMENTO e congele.

## 8. Conformidade automática

| Comando | O que faz |
|---|---|
| `python tools/nivel.py verificar` | Confere `modo:` e `nivel:`, arquivos obrigatórios, placeholders `<...>` (erro em EXECUÇÃO, aviso em PLANEJAMENTO) e tamanho do contexto-master |
| `python tools/nivel.py proteger --base origin/main` | Se a base está em EXECUÇÃO, **bloqueia** PRs que alterem `SOURCE/`, `niveis.json` ou `tools/` |

O workflow `.github/workflows/verificar-nivel.yml` roda os dois a cada push e PR. Ative **branch protection** na `main` exigindo esse check.
